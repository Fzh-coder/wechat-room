import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { UsersService } from 'src/users/users.service';

@Injectable()
export class AuthService {
  constructor(
    private usersService: UsersService,
    private jwtService: JwtService,
  ) {}

  //У���û�
  async validateUser(username: string, password: string): Promise<any> {
    const user = await this.usersService.validateUser(username, password);
    if (user) {
      //���ز�����������û���Ϣ���Ա�����JWT
      const { password, ...result } = user;
      return result;
    }
    return null;
  }

  //��¼�ɹ�������JWT
  async login(user: any) {
    const paylaod = { username: user.username, sub: user.id };
    return {
      access_token: this.jwtService.sign(paylaod),
    };
  }
}
