import { ApiProperty } from '@nestjs/swagger';

export class CreateUserDto {
  @ApiProperty({ description: 'ͷ��', example: 'avatar1.png', required: false })
  avatar?: string;

  @ApiProperty({ description: '�û���', example: 'Mike' })
  username?: string;

  @ApiProperty({ description: '����', example: '123456' })
  password?: string;
}
